-- Health Voice System — Database Schema
-- Run this file to initialize the database from scratch.
--
-- Usage:
--   psql -U health_user -d health_voice -f schema.sql

-- ─────────────────────────────────────────
-- transcripts
-- ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS transcripts (
    id              SERIAL PRIMARY KEY,
    raw_text        TEXT NOT NULL,
    normalized_text TEXT,
    source          VARCHAR(50),         -- 'voice_note' or 'batch'
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- entities
-- ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS entities (
    id              SERIAL PRIMARY KEY,
    transcript_id   INTEGER REFERENCES transcripts(id) ON DELETE CASCADE,
    entity_type     VARCHAR(50) NOT NULL,   -- intake, symptom, activity, machine, ...
    label           TEXT,
    attributes      JSONB,                  -- all type-specific fields
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_entities_transcript_id ON entities(transcript_id);
CREATE INDEX IF NOT EXISTS idx_entities_entity_type   ON entities(entity_type);

-- ─────────────────────────────────────────
-- corrections
-- Whisper ASR normalization corrections learned from user review.
-- ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS corrections (
    id               SERIAL PRIMARY KEY,
    original_text    TEXT NOT NULL,
    corrected_text   TEXT NOT NULL,
    correction_type  VARCHAR(50) DEFAULT 'normalization',
    is_normalization BOOLEAN DEFAULT TRUE,
    context_hint     TEXT,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_corrections_original ON corrections(original_text);

-- ─────────────────────────────────────────
-- knowledge_base
-- Canonical registry, removal rules, and classification corrections.
-- correction_type values: 'registry' | 'removal' | 'classification'
-- ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS knowledge_base (
    id               SERIAL PRIMARY KEY,
    original_text    TEXT NOT NULL,
    correction_type  VARCHAR(50) NOT NULL,
    corrected_value  TEXT,
    context_hint     TEXT,
    reason           TEXT,
    example_before   JSONB,
    example_after    JSONB,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_kb_correction_type ON knowledge_base(correction_type);
CREATE INDEX IF NOT EXISTS idx_kb_original_text   ON knowledge_base(original_text);