-- Health Voice System — Seed Data
-- Learned corrections and knowledge base entries.
--
-- Run AFTER schema.sql:
--   psql -U health_user -d health_voice -f seed_data.sql

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET client_min_messages = warning;

-- ─────────────────────────────────────────
-- corrections
-- ─────────────────────────────────────────

INSERT INTO public.corrections VALUES (1, 'omega stuff', 'omega-3', 'normalization', true, '2026-03-25 21:39:09.694044+03', 'took my ashwagandha and some omega stuff');
INSERT INTO public.corrections VALUES (2, 'QI stat', 'QIAstat', 'normalization', true, '2026-03-25 21:58:12.12936+03', 'going to take a QI stat today to see');
INSERT INTO public.corrections VALUES (3, 'Keroizawa', 'Karuizawa', 'normalization', true, '2026-03-25 21:58:13.492126+03', 'dry air here in Keroizawa but I am');
INSERT INTO public.corrections VALUES (4, 'lines main', 'Lion''s Mane', 'normalization', true, '2026-03-27 03:22:57.019863+03', 'I also took the new lines main capsule');
INSERT INTO public.corrections VALUES (5, 'sordo', 'sourdough', 'normalization', true, '2026-03-27 03:29:10.565883+03', 'avocado and some of the sordo that was left quick meal');
INSERT INTO public.corrections VALUES (6, 'cold easy', 'Cold-Eeze', 'normalization', true, '2026-03-27 04:01:36.56973+03', 'zinc lozenge, like the cold easy kind');
INSERT INTO public.corrections VALUES (7, 'HIV', 'HRV', 'normalization', true, '2026-03-27 04:01:41.24267+03', 'My HIV tanked overnight, 38, which');
INSERT INTO public.corrections VALUES (8, 'tutka', 'tudca', 'normalization', true, '2026-03-27 04:07:27.232062+03', 'wants me to add tutka to the stack 250');
INSERT INTO public.corrections VALUES (9, 'polar', 'Polar', 'normalization', true, '2026-03-27 04:15:07.28423+03', 'no heart rate data because I forgot the polar at home');
INSERT INTO public.corrections VALUES (10, 'verbarin', 'berberine', 'normalization', true, '2026-03-27 04:29:22.315406+03', 'The verbarin dose change was three weeks ago');
INSERT INTO public.corrections VALUES (11, 'left cough', 'left calf', 'normalization', true, '2026-03-27 04:33:15.851394+03', 'twitching in my left cough like a muscle');
INSERT INTO public.corrections VALUES (12, 'circadian routine entertainment', 'circadian rhythm entrainment', 'normalization', true, '2026-03-27 04:35:50.571655+03', 'this for circadian routine entertainment. Only day two');
INSERT INTO public.corrections VALUES (13, 'morning neck', 'morning NAC', 'normalization', true, '2026-03-27 04:50:25.817689+03', 'supplements today except the morning neck and creatine');
INSERT INTO public.corrections VALUES (14, 'Literal site', 'Lateral side', 'normalization', true, '2026-03-27 04:50:27.506516+03', 'kilometer 18 Literal site probably ITB related');
INSERT INTO public.corrections VALUES (15, 'FPB', 'PB', 'normalization', true, '2026-03-27 04:51:23.852895+03', 'That''s an FPB for me by about four minutes');
INSERT INTO public.corrections VALUES (16, 'cis orange', 'SiS orange', 'normalization', true, '2026-03-27 04:51:27.863062+03', '14k bought the cis orange ones Drank at every');
INSERT INTO public.corrections VALUES (17, 'domes', 'DOMS', 'normalization', true, '2026-03-27 04:51:31.106592+03', 'Expected domes is going to be real tomorrow');
INSERT INTO public.corrections VALUES (18, '520 per kilometer', '5:20 per kilometer', 'normalization', true, '2026-03-27 04:52:15.387139+03', 'I was running around 520 per kilometer Second');
INSERT INTO public.corrections VALUES (19, 'burpuring timing', 'berberine', 'normalization', true, '2026-03-27 05:05:46.738742+03', 'the earlier burpuring timing and I also');
INSERT INTO public.corrections VALUES (20, 'bills', 'Bills', 'normalization', true, '2026-03-27 17:39:45.989853+03', 'big group at a place called bills I had eggs');
INSERT INTO public.corrections VALUES (21, 'magnesium glycid glycinate', 'magnesium glycinate', 'normalization', true, '2026-03-27 17:55:50.857711+03', 'took magnesium glycid glycinate and the glycine');
INSERT INTO public.corrections VALUES (22, 'Sumatran pen', 'Sumatriptan', 'normalization', true, '2026-03-27 21:42:25.224137+03', 'I took one Sumatran pen 50 milligram as');
INSERT INTO public.corrections VALUES (23, 'Serrel', 'Cerelle', 'normalization', true, '2026-03-27 21:42:56.177415+03', 'I''m on Serrel, which is the mini');
INSERT INTO public.corrections VALUES (24, 'soap', 'soup', 'normalization', true, '2026-03-27 21:43:06.111486+03', 'Just some toast and soap. I also');
INSERT INTO public.corrections VALUES (25, 'Everel patch', 'Evorel patch', 'normalization', true, '2026-03-27 21:59:41.478146+03', 'I''m on a low dose of HRT. The Everel patch. Changed it on Tuesday');
INSERT INTO public.corrections VALUES (26, 'magnesium tyrannoate', 'magnesium threonate ', 'normalization', true, '2026-03-27 22:00:17.824972+03', 'Black cohosh which I got from Holland and Barrett and magnesium tyrannoate before bed');
INSERT INTO public.corrections VALUES (27, 'light explosion', 'light exposure', 'normalization', true, '2026-03-27 22:04:51.706455+03', 'change in seasons and light explosion. No supplements');
INSERT INTO public.corrections VALUES (28, 'postnatal weight vitamins', 'postnatal vitamins', 'normalization', true, '2026-03-27 22:13:29.985439+03', 'Took the postnatal weight vitamins this morning');
INSERT INTO public.corrections VALUES (29, 'seven C''s one', 'Sevenseas one', 'normalization', true, '2026-03-27 22:13:47.016627+03', 'vitamins this morning, the seven C''s one, also the iron');
INSERT INTO public.corrections VALUES (30, 'psycho', 'physio', 'normalization', true, '2026-03-27 22:29:25.032651+03', 'Mom says I should see the psycho but');
INSERT INTO public.corrections VALUES (31, 'Whiting scale', 'Withings scale', 'normalization', true, '2026-03-27 23:38:23.191239+03', 'weight 73.8 on the Whiting scale, slept 7 hours');
INSERT INTO public.corrections VALUES (32, 'Libra', 'Libre', 'normalization', true, '2026-03-27 23:38:28.653796+03', 'glucose on waking was 4.9 on the Libra which is good');
INSERT INTO public.corrections VALUES (33, 'KCM 63', 'KSM-66', 'normalization', true, '2026-03-27 23:38:48.851391+03', 'NAC 600mg and ashwagandha, KCM 63, did 30 minutes');
INSERT INTO public.corrections VALUES (34, 'who kept power under 180 watts', 'Wahoo, kept power under 180 watts', 'normalization', true, '2026-03-27 23:40:17.502215+03', 'zone 2 cycling on the who kept power under');
INSERT INTO public.corrections VALUES (35, 'nothing to flack', 'nothing to flag', 'normalization', true, '2026-03-27 23:40:20.646246+03', 'coffee after, all morning nothing to flack');
INSERT INTO public.corrections VALUES (36, 'dirolytes', 'Dioralyte', 'normalization', true, '2026-03-28 00:02:39.918185+03', 'electrolyte sachets, the dirolytes ones. Not eating');
INSERT INTO public.corrections VALUES (37, 'Ketrotide', 'Cetrotide', 'normalization', true, '2026-03-28 00:07:46.15024+03', 'Gonal F 150 units and the Ketrotide 0.25 milligram');
INSERT INTO public.corrections VALUES (38, 'semiagglutate', 'semaglutide', 'normalization', true, '2026-03-28 00:13:54.792608+03', 'adding a GLP-1 like semiagglutate first');
INSERT INTO public.corrections VALUES (39, 'levotroxine', 'levothyroxine', 'normalization', true, '2026-03-28 00:14:09.430417+03', 'I also took my levotroxine 75 milligram');
INSERT INTO public.corrections VALUES (40, 'get out of run', 'get out for a run', 'normalization', true, '2026-03-28 00:17:38.280477+03', 'I did manage to get out of run this morning');
INSERT INTO public.corrections VALUES (41, 'BP', 'PB', 'normalization', true, '2026-03-28 00:28:07.788371+03', 'which is a new BP for me');
INSERT INTO public.corrections VALUES (42, 'Derelict', 'Relight', 'normalization', true, '2026-03-28 21:51:35.449951+03', 'berberine all of that also Derelict and creatine');
INSERT INTO public.corrections VALUES (43, 'Nat Plus', 'NAD Plus', 'normalization', true, '2026-03-28 22:20:52.317089+03', 'had the Nat Plus infusion, the third');
INSERT INTO public.corrections VALUES (44, 'The Novator today obviously', 'No Novothor today obviously', 'normalization', true, '2026-03-28 22:33:59.047051+03', 'tomorrow. I think The Novator today obviously going to take');
INSERT INTO public.corrections VALUES (45, 'circadine', 'circadian', 'normalization', true, '2026-03-28 23:01:02.369368+03', 'I took glycine circadine and I did');

SELECT pg_catalog.setval('public.corrections_id_seq', 45, true);

-- ─────────────────────────────────────────
-- knowledge_base
-- ─────────────────────────────────────────

INSERT INTO public.knowledge_base VALUES (1, 'QIAstat', 'registry', 'diagnostic_test', '', '', '{"aliases": ["qı stat", "q stat"]}', '{"subtype": "", "description": "QIAstat is a modular syndromic testing system used for rapid and versatile molecular diagnostics. It can quickly detect various infectious diseases including respiratory tract, gastrointestinal, and meningitis panels.", "likely_types": ["test"], "unlikely_types": []}', '2026-03-25 19:31:42.818142+03');
INSERT INTO public.knowledge_base VALUES (3, 'Novothor ', 'registry', 'machine', NULL, NULL, '{"aliases": ["Novathor"]}', '{"subtype": "photobiomodulation bed", "description": "Full-body red light therapy device"}', '2026-03-25 20:58:07.527895+03');
INSERT INTO public.knowledge_base VALUES (4, 'Vielight chest piece', 'registry', 'machine', NULL, NULL, '{"aliases": ["VioLite chest piece", "VioLite chest"]}', '{"subtype": "photobiomodulation device", "description": "Chest applicator for red/NIR light therapy"}', '2026-03-25 20:59:05.610122+03');
INSERT INTO public.knowledge_base VALUES (5, 'Vielight nose light', 'registry', 'machine', NULL, NULL, '{"aliases": ["VioLite nose light", "VioLite nose"]}', '{"subtype": "photobiomodulation device", "description": "Nasal applicator for red/NIR light therapy"}', '2026-03-25 20:59:43.921026+03');
INSERT INTO public.knowledge_base VALUES (7, 'HUME', 'registry', 'device', NULL, NULL, '{"aliases": ["hume"]}', '{"subtype": "body composition scale", "description": "Body weight and composition scale"}', '2026-03-25 21:03:37.864375+03');
INSERT INTO public.knowledge_base VALUES (8, 'Plaud', 'registry', 'device', NULL, NULL, '{"aliases": []}', '{"subtype": "voice recorder", "description": "Wearable voice recording device"}', '2026-03-25 21:04:13.823444+03');
INSERT INTO public.knowledge_base VALUES (9, 'Relight', 'registry', 'intake', NULL, NULL, '{"aliases": []}', '{"subtype": "electrolyte supplement", "description": "Electrolyte and recovery drink"}', '2026-03-25 21:04:55.014206+03');
INSERT INTO public.knowledge_base VALUES (10, 'PHGG', 'registry', 'intake', NULL, NULL, '{"aliases": []}', '{"subtype": "prebiotic fiber", "description": "Partially hydrolyzed guar gum, prescribed as gut supplement"}', '2026-03-25 21:05:27.128625+03');
INSERT INTO public.knowledge_base VALUES (11, 'Citrulline', 'registry', 'intake', NULL, NULL, '{"aliases": ["circuit"]}', '{"subtype": "amino acid supplement", "description": "Performance and circulation supplement"}', '2026-03-25 21:06:03.078347+03');
INSERT INTO public.knowledge_base VALUES (12, 'Psyllium husk', 'registry', 'intake', NULL, NULL, '{"aliases": ["selenium husk"]}', '{"subtype": "fiber supplement", "description": "Soluble fiber supplement"}', '2026-03-25 21:06:47.999325+03');
INSERT INTO public.knowledge_base VALUES (13, 'Oura Ring', 'registry', 'device', NULL, NULL, '{"aliases": ["oura", "ovary"]}', '{"subtype": "wearable tracker", "description": "Sleep, HRV and activity tracker"}', '2026-03-25 21:38:08.673058+03');
INSERT INTO public.knowledge_base VALUES (14, 'aura', 'classification', 'other', 'The aura came first About 20', 'user changed type from symptom to other', '{"raw_mention": "aura", "candidate_type": "symptom"}', '{"raw_mention": "aura", "candidate_type": "other"}', '2026-03-27 21:49:09.612238+03');
INSERT INTO public.knowledge_base VALUES (15, 'usual supplements', 'classification', 'other', 'I took my usual supplements except', 'user changed type from intake to other', '{"raw_mention": "usual supplements", "candidate_type": "intake"}', '{"raw_mention": "usual supplements", "candidate_type": "other"}', '2026-03-27 23:59:57.394216+03');
INSERT INTO public.knowledge_base VALUES (16, 'PHGG', 'classification', 'intake', 'I''m not sure why the PHGG wasn''t ordered', 'user changed type from theory to intake', '{"raw_mention": "PHGG", "candidate_type": "theory"}', '{"raw_mention": "PHGG", "candidate_type": "intake"}', '2026-03-28 22:50:55.069612+03');
INSERT INTO public.knowledge_base VALUES (17, 'nasopharyngeal prodromal pain', 'registry', 'symptom', NULL, NULL, '{"aliases": []}', '{"subtype": "prodromal symptom", "description": "Gabriel''s personal early warning sign. Pain or tickle at the junction of nasal cavity and throat. Precedes illness onset 90%+ of the time. Not a general sore throat."}', '2026-03-29 02:20:06.073019+03');
INSERT INTO public.knowledge_base VALUES (19, 'circadine', 'registry', 'intake', NULL, NULL, '{"aliases": []}', '{"subtype": "sleep supplement", "description": "Sleep support supplement."}', '2026-03-29 02:28:33.845175+03');
INSERT INTO public.knowledge_base VALUES (20, 'glycine', 'registry', 'intake', NULL, NULL, '{"aliases": []}', '{"subtype": "sleep supplement / amino acid", "description": "Amino acid supplement. Commonly taken for sleep support."}', '2026-03-29 02:31:53.649878+03');
INSERT INTO public.knowledge_base VALUES (21, 'wake up supplements', 'removal', NULL, NULL, 'Vague group label, not resolvable to specific substances. Cannot be tracked over time.', NULL, NULL, '2026-03-29 02:36:53.420816+03');

SELECT pg_catalog.setval('public.knowledge_base_id_seq', 21, true);